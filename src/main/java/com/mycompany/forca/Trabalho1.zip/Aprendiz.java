
package com.mycompany.forca;

/**
 *
 * @author Eduar
 */
public class Aprendiz extends Sith {

    
    public Aprendiz(int vida, String nome) {
       
        super(40, vida, nome);
    }
}
