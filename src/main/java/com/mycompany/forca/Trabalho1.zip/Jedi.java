
package com.mycompany.forca;

/**
 *
 * @author Eduar
 */


public class Jedi extends Forca {

    
    public Jedi(int forca, int vida, String nome) {
        
        super(forca, vida, "Jedi", nome);
    }
}