
package com.mycompany.forca;

/**
 *
 * @author Eduar
 */

public class Sith extends Forca {

    
    public Sith(int forca, int vida, String nome) {
       
        super(forca, vida, "Sith", nome);
    }
}
