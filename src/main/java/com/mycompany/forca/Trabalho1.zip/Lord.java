
package com.mycompany.forca;

/**
 *
 * @author Eduar
 */
public class Lord extends Sith {

    
    public Lord(int vida, String nome) {
        
        super(80, vida, nome);
    }
}
