
package com.mycompany.forca;

/**
 *
 * @author Eduar
 */
public class Cavaleiro extends Jedi {

    
    public Cavaleiro(int vida, String nome) {
        
        super(70, vida, nome);
    }
}
