
package com.mycompany.forca;

/**
 *
 * @author Eduar
 */
public class Padawan extends Jedi {

    
    public Padawan(int vida, String nome) {
        
        super(20, vida, nome);
    }
}
